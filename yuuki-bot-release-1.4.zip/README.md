# Yuuki-Bot v1.4
A discord.js-based Discord bot for personal use. Yes these commit messages are extremely dumb.

## Todo
- !!!Update to discord.js v12!!!
- Give Noah a therapy bot because this is the age we live in (make him code it if he wants it)
- Create Say command

## Requirements
- NodeJS > 7.0

## Setup
```
cp .env.sample .env
npm install
npm start
```
